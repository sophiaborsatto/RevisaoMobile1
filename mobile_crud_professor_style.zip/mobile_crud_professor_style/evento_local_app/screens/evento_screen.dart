import 'package:flutter/material.dart';

class Evento {
  int id;
  String titulo;
  String categoria;
  String data;

  Evento({required this.id, required this.titulo, required this.categoria, required this.data});
}

class EventoScreen extends StatefulWidget {
  const EventoScreen({super.key});

  @override
  State<EventoScreen> createState() => _EventoScreenState();
}

class _EventoScreenState extends State<EventoScreen> {
  final List<Evento> eventos = [];
  final TextEditingController tituloController = TextEditingController();
  final TextEditingController categoriaController = TextEditingController();
  final TextEditingController dataController = TextEditingController();
  int proximoId = 1;
  Evento? eventoEmEdicao;

  @override
  void dispose() {
    tituloController.dispose();
    categoriaController.dispose();
    dataController.dispose();
    super.dispose();
  }

  void limparCampos() {
    tituloController.clear();
    categoriaController.clear();
    dataController.clear();
    eventoEmEdicao = null;
  }

  void abrirFormulario([Evento? evento]) {
    if (evento != null) {
      eventoEmEdicao = evento;
      tituloController.text = evento.titulo;
      categoriaController.text = evento.categoria;
      dataController.text = evento.data;
    } else {
      limparCampos();
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(evento == null ? 'Cadastrar evento' : 'Editar evento'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: tituloController,
                decoration: const InputDecoration(labelText: 'Título'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: categoriaController,
                decoration: const InputDecoration(labelText: 'Categoria'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: dataController,
                decoration: const InputDecoration(labelText: 'Data'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                limparCampos();
                Navigator.pop(context);
              },
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: salvarEvento,
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  void salvarEvento() {
    final String titulo = tituloController.text.trim();
    final String categoria = categoriaController.text.trim();
    final String data = dataController.text.trim();

    if (titulo.isEmpty || categoria.isEmpty || data.isEmpty) {
      return;
    }

    setState(() {
      if (eventoEmEdicao == null) {
        eventos.add(Evento(id: proximoId, titulo: titulo, categoria: categoria, data: data));
        proximoId++;
      } else {
        eventoEmEdicao!.titulo = titulo;
        eventoEmEdicao!.categoria = categoria;
        eventoEmEdicao!.data = data;
      }
    });

    limparCampos();
    Navigator.pop(context);
  }

  void excluirEvento(Evento evento) {
    setState(() {
      eventos.remove(evento);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CRUD de Evento'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: eventos.isEmpty
          ? const Center(child: Text('Nenhum evento cadastrado'))
          : ListView.builder(
              itemCount: eventos.length,
              itemBuilder: (context, index) {
                final Evento evento = eventos[index];
                return Card(
                  child: ListTile(
                    title: Text(evento.titulo),
                    subtitle: Text('Categoria: ${evento.categoria} | Data: ${evento.data}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () => abrirFormulario(evento),
                          icon: const Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () => excluirEvento(evento),
                          icon: const Icon(Icons.delete),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => abrirFormulario(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
