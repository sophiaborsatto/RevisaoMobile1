import 'package:flutter/material.dart';

class LocalItem {
  int id;
  String nome;
  String endereco;
  int capacidade;

  LocalItem({required this.id, required this.nome, required this.endereco, required this.capacidade});
}

class LocalScreen extends StatefulWidget {
  const LocalScreen({super.key});

  @override
  State<LocalScreen> createState() => _LocalScreenState();
}

class _LocalScreenState extends State<LocalScreen> {
  final List<LocalItem> locais = [];
  final TextEditingController nomeController = TextEditingController();
  final TextEditingController enderecoController = TextEditingController();
  final TextEditingController capacidadeController = TextEditingController();
  int proximoId = 1;
  LocalItem? localEmEdicao;

  @override
  void dispose() {
    nomeController.dispose();
    enderecoController.dispose();
    capacidadeController.dispose();
    super.dispose();
  }

  void limparCampos() {
    nomeController.clear();
    enderecoController.clear();
    capacidadeController.clear();
    localEmEdicao = null;
  }

  void abrirFormulario([LocalItem? local]) {
    if (local != null) {
      localEmEdicao = local;
      nomeController.text = local.nome;
      enderecoController.text = local.endereco;
      capacidadeController.text = local.capacidade.toString();
    } else {
      limparCampos();
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(local == null ? 'Cadastrar local' : 'Editar local'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nomeController,
                decoration: const InputDecoration(labelText: 'Nome do local'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: enderecoController,
                decoration: const InputDecoration(labelText: 'Endereço'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: capacidadeController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Capacidade'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                limparCampos();
                Navigator.pop(context);
              },
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: salvarLocal,
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  void salvarLocal() {
    final String nome = nomeController.text.trim();
    final String endereco = enderecoController.text.trim();
    final int capacidade = int.tryParse(capacidadeController.text) ?? 0;

    if (nome.isEmpty || endereco.isEmpty) {
      return;
    }

    setState(() {
      if (localEmEdicao == null) {
        locais.add(LocalItem(id: proximoId, nome: nome, endereco: endereco, capacidade: capacidade));
        proximoId++;
      } else {
        localEmEdicao!.nome = nome;
        localEmEdicao!.endereco = endereco;
        localEmEdicao!.capacidade = capacidade;
      }
    });

    limparCampos();
    Navigator.pop(context);
  }

  void excluirLocal(LocalItem local) {
    setState(() {
      locais.remove(local);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CRUD de Local'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: locais.isEmpty
          ? const Center(child: Text('Nenhum local cadastrado'))
          : ListView.builder(
              itemCount: locais.length,
              itemBuilder: (context, index) {
                final LocalItem local = locais[index];
                return Card(
                  child: ListTile(
                    title: Text(local.nome),
                    subtitle: Text('Endereço: ${local.endereco} | Capacidade: ${local.capacidade}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () => abrirFormulario(local),
                          icon: const Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () => excluirLocal(local),
                          icon: const Icon(Icons.delete),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => abrirFormulario(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
