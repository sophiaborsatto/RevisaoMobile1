import 'package:flutter/material.dart';

class Computador {
  int id;
  String marca;
  String processador;
  int memoriaRam;

  Computador({required this.id, required this.marca, required this.processador, required this.memoriaRam});
}

class ComputadorScreen extends StatefulWidget {
  const ComputadorScreen({super.key});

  @override
  State<ComputadorScreen> createState() => _ComputadorScreenState();
}

class _ComputadorScreenState extends State<ComputadorScreen> {
  final List<Computador> computadores = [];
  final TextEditingController marcaController = TextEditingController();
  final TextEditingController processadorController = TextEditingController();
  final TextEditingController memoriaRamController = TextEditingController();
  int proximoId = 1;
  Computador? computadorEmEdicao;

  @override
  void dispose() {
    marcaController.dispose();
    processadorController.dispose();
    memoriaRamController.dispose();
    super.dispose();
  }

  void limparCampos() {
    marcaController.clear();
    processadorController.clear();
    memoriaRamController.clear();
    computadorEmEdicao = null;
  }

  void abrirFormulario([Computador? computador]) {
    if (computador != null) {
      computadorEmEdicao = computador;
      marcaController.text = computador.marca;
      processadorController.text = computador.processador;
      memoriaRamController.text = computador.memoriaRam.toString();
    } else {
      limparCampos();
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(computador == null ? 'Cadastrar computador' : 'Editar computador'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: marcaController,
                decoration: const InputDecoration(labelText: 'Marca'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: processadorController,
                decoration: const InputDecoration(labelText: 'Processador'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: memoriaRamController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Memória RAM (GB)'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                limparCampos();
                Navigator.pop(context);
              },
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: salvarComputador,
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  void salvarComputador() {
    final String marca = marcaController.text.trim();
    final String processador = processadorController.text.trim();
    final int memoriaRam = int.tryParse(memoriaRamController.text) ?? 0;

    if (marca.isEmpty || processador.isEmpty) {
      return;
    }

    setState(() {
      if (computadorEmEdicao == null) {
        computadores.add(
          Computador(
            id: proximoId,
            marca: marca,
            processador: processador,
            memoriaRam: memoriaRam,
          ),
        );
        proximoId++;
      } else {
        computadorEmEdicao!.marca = marca;
        computadorEmEdicao!.processador = processador;
        computadorEmEdicao!.memoriaRam = memoriaRam;
      }
    });

    limparCampos();
    Navigator.pop(context);
  }

  void excluirComputador(Computador computador) {
    setState(() {
      computadores.remove(computador);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CRUD de Computador'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: computadores.isEmpty
          ? const Center(child: Text('Nenhum computador cadastrado'))
          : ListView.builder(
              itemCount: computadores.length,
              itemBuilder: (context, index) {
                final Computador computador = computadores[index];
                return Card(
                  child: ListTile(
                    title: Text(computador.marca),
                    subtitle: Text('Processador: ${computador.processador} | RAM: ${computador.memoriaRam} GB'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () => abrirFormulario(computador),
                          icon: const Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () => excluirComputador(computador),
                          icon: const Icon(Icons.delete),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => abrirFormulario(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
