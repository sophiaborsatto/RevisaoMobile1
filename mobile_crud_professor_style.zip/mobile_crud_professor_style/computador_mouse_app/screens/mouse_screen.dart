import 'package:flutter/material.dart';

class MouseItem {
  int id;
  String marca;
  int dpi;
  String tipo;

  MouseItem({required this.id, required this.marca, required this.dpi, required this.tipo});
}

class MouseScreen extends StatefulWidget {
  const MouseScreen({super.key});

  @override
  State<MouseScreen> createState() => _MouseScreenState();
}

class _MouseScreenState extends State<MouseScreen> {
  final List<MouseItem> mouses = [];
  final TextEditingController marcaController = TextEditingController();
  final TextEditingController dpiController = TextEditingController();
  final TextEditingController tipoController = TextEditingController();
  int proximoId = 1;
  MouseItem? mouseEmEdicao;

  @override
  void dispose() {
    marcaController.dispose();
    dpiController.dispose();
    tipoController.dispose();
    super.dispose();
  }

  void limparCampos() {
    marcaController.clear();
    dpiController.clear();
    tipoController.clear();
    mouseEmEdicao = null;
  }

  void abrirFormulario([MouseItem? mouse]) {
    if (mouse != null) {
      mouseEmEdicao = mouse;
      marcaController.text = mouse.marca;
      dpiController.text = mouse.dpi.toString();
      tipoController.text = mouse.tipo;
    } else {
      limparCampos();
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(mouse == null ? 'Cadastrar mouse' : 'Editar mouse'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: marcaController,
                decoration: const InputDecoration(labelText: 'Marca'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: dpiController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'DPI'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: tipoController,
                decoration: const InputDecoration(labelText: 'Tipo'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                limparCampos();
                Navigator.pop(context);
              },
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: salvarMouse,
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  void salvarMouse() {
    final String marca = marcaController.text.trim();
    final int dpi = int.tryParse(dpiController.text) ?? 0;
    final String tipo = tipoController.text.trim();

    if (marca.isEmpty || tipo.isEmpty) {
      return;
    }

    setState(() {
      if (mouseEmEdicao == null) {
        mouses.add(MouseItem(id: proximoId, marca: marca, dpi: dpi, tipo: tipo));
        proximoId++;
      } else {
        mouseEmEdicao!.marca = marca;
        mouseEmEdicao!.dpi = dpi;
        mouseEmEdicao!.tipo = tipo;
      }
    });

    limparCampos();
    Navigator.pop(context);
  }

  void excluirMouse(MouseItem mouse) {
    setState(() {
      mouses.remove(mouse);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CRUD de Mouse'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: mouses.isEmpty
          ? const Center(child: Text('Nenhum mouse cadastrado'))
          : ListView.builder(
              itemCount: mouses.length,
              itemBuilder: (context, index) {
                final MouseItem mouse = mouses[index];
                return Card(
                  child: ListTile(
                    title: Text(mouse.marca),
                    subtitle: Text('DPI: ${mouse.dpi} | Tipo: ${mouse.tipo}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () => abrirFormulario(mouse),
                          icon: const Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () => excluirMouse(mouse),
                          icon: const Icon(Icons.delete),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => abrirFormulario(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
