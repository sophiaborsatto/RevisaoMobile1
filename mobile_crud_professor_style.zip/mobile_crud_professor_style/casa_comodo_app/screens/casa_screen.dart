import 'package:flutter/material.dart';

class Casa {
  int id;
  String nome;
  String endereco;

  Casa({required this.id, required this.nome, required this.endereco});
}

class CasaScreen extends StatefulWidget {
  const CasaScreen({super.key});

  @override
  State<CasaScreen> createState() => _CasaScreenState();
}

class _CasaScreenState extends State<CasaScreen> {
  final List<Casa> casas = [];
  final TextEditingController nomeController = TextEditingController();
  final TextEditingController enderecoController = TextEditingController();
  int proximoId = 1;
  Casa? casaEmEdicao;

  @override
  void dispose() {
    nomeController.dispose();
    enderecoController.dispose();
    super.dispose();
  }

  void limparCampos() {
    nomeController.clear();
    enderecoController.clear();
    casaEmEdicao = null;
  }

  void abrirFormulario([Casa? casa]) {
    if (casa != null) {
      casaEmEdicao = casa;
      nomeController.text = casa.nome;
      enderecoController.text = casa.endereco;
    } else {
      limparCampos();
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(casa == null ? 'Cadastrar casa' : 'Editar casa'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nomeController,
                decoration: const InputDecoration(labelText: 'Nome da casa'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: enderecoController,
                decoration: const InputDecoration(labelText: 'Endereço'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                limparCampos();
                Navigator.pop(context);
              },
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: salvarCasa,
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  void salvarCasa() {
    final String nome = nomeController.text.trim();
    final String endereco = enderecoController.text.trim();

    if (nome.isEmpty || endereco.isEmpty) {
      return;
    }

    setState(() {
      if (casaEmEdicao == null) {
        casas.add(Casa(id: proximoId, nome: nome, endereco: endereco));
        proximoId++;
      } else {
        casaEmEdicao!.nome = nome;
        casaEmEdicao!.endereco = endereco;
      }
    });

    limparCampos();
    Navigator.pop(context);
  }

  void excluirCasa(Casa casa) {
    setState(() {
      casas.remove(casa);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CRUD de Casa'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: casas.isEmpty
          ? const Center(child: Text('Nenhuma casa cadastrada'))
          : ListView.builder(
              itemCount: casas.length,
              itemBuilder: (context, index) {
                final Casa casa = casas[index];
                return Card(
                  child: ListTile(
                    title: Text(casa.nome),
                    subtitle: Text('Endereço: ${casa.endereco}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () => abrirFormulario(casa),
                          icon: const Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () => excluirCasa(casa),
                          icon: const Icon(Icons.delete),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => abrirFormulario(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
