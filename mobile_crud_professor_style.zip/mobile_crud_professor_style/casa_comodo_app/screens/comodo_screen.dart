import 'package:flutter/material.dart';

class Comodo {
  int id;
  String nome;
  String tipo;
  double area;

  Comodo({required this.id, required this.nome, required this.tipo, required this.area});
}

class ComodoScreen extends StatefulWidget {
  const ComodoScreen({super.key});

  @override
  State<ComodoScreen> createState() => _ComodoScreenState();
}

class _ComodoScreenState extends State<ComodoScreen> {
  final List<Comodo> comodos = [];
  final TextEditingController nomeController = TextEditingController();
  final TextEditingController tipoController = TextEditingController();
  final TextEditingController areaController = TextEditingController();
  int proximoId = 1;
  Comodo? comodoEmEdicao;

  @override
  void dispose() {
    nomeController.dispose();
    tipoController.dispose();
    areaController.dispose();
    super.dispose();
  }

  void limparCampos() {
    nomeController.clear();
    tipoController.clear();
    areaController.clear();
    comodoEmEdicao = null;
  }

  void abrirFormulario([Comodo? comodo]) {
    if (comodo != null) {
      comodoEmEdicao = comodo;
      nomeController.text = comodo.nome;
      tipoController.text = comodo.tipo;
      areaController.text = comodo.area.toString();
    } else {
      limparCampos();
    }

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(comodo == null ? 'Cadastrar cômodo' : 'Editar cômodo'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nomeController,
                decoration: const InputDecoration(labelText: 'Nome do cômodo'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: tipoController,
                decoration: const InputDecoration(labelText: 'Tipo'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: areaController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Área'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                limparCampos();
                Navigator.pop(context);
              },
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: salvarComodo,
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  void salvarComodo() {
    final String nome = nomeController.text.trim();
    final String tipo = tipoController.text.trim();
    final double area = double.tryParse(areaController.text) ?? 0;

    if (nome.isEmpty || tipo.isEmpty) {
      return;
    }

    setState(() {
      if (comodoEmEdicao == null) {
        comodos.add(Comodo(id: proximoId, nome: nome, tipo: tipo, area: area));
        proximoId++;
      } else {
        comodoEmEdicao!.nome = nome;
        comodoEmEdicao!.tipo = tipo;
        comodoEmEdicao!.area = area;
      }
    });

    limparCampos();
    Navigator.pop(context);
  }

  void excluirComodo(Comodo comodo) {
    setState(() {
      comodos.remove(comodo);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CRUD de Cômodo'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: comodos.isEmpty
          ? const Center(child: Text('Nenhum cômodo cadastrado'))
          : ListView.builder(
              itemCount: comodos.length,
              itemBuilder: (context, index) {
                final Comodo comodo = comodos[index];
                return Card(
                  child: ListTile(
                    title: Text(comodo.nome),
                    subtitle: Text('Tipo: ${comodo.tipo} | Área: ${comodo.area} m²'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          onPressed: () => abrirFormulario(comodo),
                          icon: const Icon(Icons.edit),
                        ),
                        IconButton(
                          onPressed: () => excluirComodo(comodo),
                          icon: const Icon(Icons.delete),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => abrirFormulario(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
