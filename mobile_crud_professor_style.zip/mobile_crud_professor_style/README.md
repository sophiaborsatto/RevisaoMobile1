# CRUDs atualizados no estilo do professor

Este pacote foi ajustado para ficar mais próximo do resumo enviado pelo professor:

- arquivos em `snake_case`
- telas com sufixo `_screen.dart`
- classes e widgets em `PascalCase`
- variáveis e funções em `camelCase`
- uso de `StatefulWidget`
- uso de `TextEditingController`
- uso de `setState(() {})`
- uso de `int.tryParse` e `double.tryParse`
- estrutura simples, boa para prova

## Estrutura dos exemplos

Cada pasta tem:

- `main.dart`
- `screens/home_screen.dart`
- telas de CRUD separadas

## Como estudar

1. Abra primeiro o exemplo `casa_comodo_app`
2. Entenda o padrão de uma tela CRUD
3. Perceba que os outros seguem a mesma lógica
4. Na prova, troque só o tema, os campos e os textos
